import { DramaGenerator } from '@/components/drama-generator'

export default function Home() {
  return <DramaGenerator />
}
