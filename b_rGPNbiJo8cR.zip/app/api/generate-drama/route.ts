import { streamText } from 'ai'

export const maxDuration = 60

export async function POST(req: Request) {
  const { prompt, genre, length } = await req.json()

  const systemPrompt = `你是一位专业的短剧编剧，擅长创作引人入胜的短剧剧本。请根据用户提供的主题和要求，创作一个精彩的短剧剧本。

要求：
1. 剧本应包含场景描述、角色对话和情感指导
2. 情节紧凑，有起承转合
3. 对话自然生动，符合角色性格
4. 适当添加悬念和冲突
5. 结局要有意义或留有回味

格式要求：
- 使用【场景】标注场景
- 使用角色名+冒号表示对话
- 用（括号）标注动作和表情
- 用[方括号]标注情绪/语气指导`

  const userPrompt = `请创作一个${length}分钟的${genre}短剧，主题是：${prompt}

请确保剧本精彩、引人入胜，适合短视频平台播出。`

  const result = streamText({
    model: 'openai/gpt-4o-mini',
    system: systemPrompt,
    prompt: userPrompt,
    abortSignal: req.signal,
  })

  return result.toTextStreamResponse()
}
