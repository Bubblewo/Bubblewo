'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent } from '@/components/ui/card'
import { Sparkles, Film, Clock, Wand2, Copy, Check, RotateCcw } from 'lucide-react'

const genres = [
  { value: '爱情', label: '爱情', icon: '💕' },
  { value: '悬疑', label: '悬疑', icon: '🔍' },
  { value: '喜剧', label: '喜剧', icon: '😄' },
  { value: '励志', label: '励志', icon: '💪' },
  { value: '都市', label: '都市', icon: '🏙️' },
  { value: '古装', label: '古装', icon: '🏯' },
]

const lengths = [
  { value: '1', label: '1分钟' },
  { value: '3', label: '3分钟' },
  { value: '5', label: '5分钟' },
]

export function DramaGenerator() {
  const [prompt, setPrompt] = useState('')
  const [genre, setGenre] = useState('爱情')
  const [length, setLength] = useState('3')
  const [result, setResult] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [copied, setCopied] = useState(false)

  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return

    setIsGenerating(true)
    setResult('')

    try {
      const response = await fetch('/api/generate-drama', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, genre, length }),
      })

      if (!response.ok) throw new Error('生成失败')

      const reader = response.body?.getReader()
      if (!reader) throw new Error('无法读取响应')

      const decoder = new TextDecoder()
      let fullText = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        const chunk = decoder.decode(value, { stream: true })
        fullText += chunk
        setResult(fullText)
      }
    } catch (error) {
      console.error('[v0] Error generating drama:', error)
      setResult('生成失败，请重试。')
    } finally {
      setIsGenerating(false)
    }
  }

  const handleCopy = async () => {
    await navigator.clipboard.writeText(result)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleReset = () => {
    setPrompt('')
    setResult('')
    setGenre('爱情')
    setLength('3')
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm bg-background/80 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Film className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="font-semibold text-lg text-foreground">AI 短剧生成器</h1>
              <p className="text-xs text-muted-foreground">让创作更简单</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground px-3 py-1 rounded-full bg-secondary">
              Beta
            </span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-medium text-foreground">
                <Sparkles className="w-4 h-4 text-primary" />
                创意输入
              </div>
              <Textarea
                placeholder="描述你想要的短剧故事，例如：一个关于程序员在咖啡店偶遇初恋的故事..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="min-h-[140px] resize-none bg-input border-border focus:border-primary focus:ring-primary/20 text-foreground placeholder:text-muted-foreground"
              />
            </div>

            {/* Genre Selection */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm font-medium text-foreground">
                <Film className="w-4 h-4 text-primary" />
                选择类型
              </div>
              <div className="grid grid-cols-3 gap-2">
                {genres.map((g) => (
                  <button
                    key={g.value}
                    onClick={() => setGenre(g.value)}
                    className={`px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 flex items-center justify-center gap-2 ${
                      genre === g.value
                        ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25'
                        : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                    }`}
                  >
                    <span>{g.icon}</span>
                    {g.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Length Selection */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm font-medium text-foreground">
                <Clock className="w-4 h-4 text-primary" />
                剧本时长
              </div>
              <div className="flex gap-2">
                {lengths.map((l) => (
                  <button
                    key={l.value}
                    onClick={() => setLength(l.value)}
                    className={`flex-1 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${
                      length === l.value
                        ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25'
                        : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                    }`}
                  >
                    {l.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Generate Button */}
            <div className="flex gap-3">
              <Button
                onClick={handleGenerate}
                disabled={!prompt.trim() || isGenerating}
                className="flex-1 h-12 text-base font-medium bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/25 transition-all duration-200"
              >
                {isGenerating ? (
                  <>
                    <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2" />
                    生成中...
                  </>
                ) : (
                  <>
                    <Wand2 className="w-5 h-5 mr-2" />
                    生成剧本
                  </>
                )}
              </Button>
              {result && (
                <Button
                  onClick={handleReset}
                  variant="outline"
                  className="h-12 px-4 border-border hover:bg-secondary"
                >
                  <RotateCcw className="w-5 h-5" />
                </Button>
              )}
            </div>
          </div>

          {/* Result Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-medium text-foreground">
                <Film className="w-4 h-4 text-primary" />
                生成结果
              </div>
              {result && !isGenerating && (
                <Button
                  onClick={handleCopy}
                  variant="ghost"
                  size="sm"
                  className="text-muted-foreground hover:text-foreground"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 mr-1" />
                      已复制
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-1" />
                      复制
                    </>
                  )}
                </Button>
              )}
            </div>
            <Card className="bg-card border-border min-h-[400px]">
              <CardContent className="p-6">
                {result ? (
                  <div className="prose prose-invert max-w-none">
                    <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed text-card-foreground">
                      {result}
                      {isGenerating && (
                        <span className="inline-block w-2 h-5 ml-1 bg-primary animate-pulse" />
                      )}
                    </pre>
                  </div>
                ) : (
                  <div className="h-full min-h-[350px] flex flex-col items-center justify-center text-muted-foreground">
                    <div className="w-16 h-16 rounded-2xl bg-secondary flex items-center justify-center mb-4">
                      <Sparkles className="w-8 h-8 text-muted-foreground/50" />
                    </div>
                    <p className="text-center text-sm">
                      输入你的创意想法
                      <br />
                      AI 将为你生成精彩的短剧剧本
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 py-6">
        <div className="max-w-5xl mx-auto px-4 text-center text-sm text-muted-foreground">
          由 AI 驱动 · 创意无限
        </div>
      </footer>
    </div>
  )
}
